// wm-charts.jsx — Chart components for WindMeter
const { useRef, useEffect, useCallback, useMemo } = React;

function WindShiftChart({ data, theme, height = 88 }) {
  const ref = useRef(null);
  useEffect(() => {
    const c = ref.current; if (!c) return;
    const ctx = c.getContext('2d');
    const W = c.width, H = c.height, mid = H / 2;
    ctx.clearRect(0, 0, W, H);
    const max = 12, bw = W / data.length;
    ctx.strokeStyle = theme.border; ctx.lineWidth = 1; ctx.setLineDash([2, 5]);
    [0.2, 0.4, 0.6, 0.8].forEach(f => {
      ctx.beginPath(); ctx.moveTo(0, H * f); ctx.lineTo(W, H * f); ctx.stroke();
    });
    ctx.setLineDash([]);
    data.forEach((d, i) => {
      const bh = (Math.abs(d.v) / max) * mid;
      ctx.globalAlpha = 0.4 + (i / data.length) * 0.6;
      ctx.fillStyle = d.v >= 0 ? theme.chartPos : theme.chartNeg;
      if (d.v >= 0) ctx.fillRect(i * bw + 1, mid - bh, bw - 2, bh);
      else ctx.fillRect(i * bw + 1, mid, bw - 2, bh);
    });
    ctx.globalAlpha = 1;
    ctx.strokeStyle = theme.textDim; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(0, mid); ctx.lineTo(W, mid); ctx.stroke();
    ctx.fillStyle = theme.textDim; ctx.font = `600 9px 'Barlow Condensed'`; ctx.textAlign = 'right';
    ['+10°', '+5°', '−5°', '−10°'].forEach((l, i) => {
      ctx.fillText(l, W - 2, [H * 0.1, H * 0.3, H * 0.7, H * 0.9][i] + 3);
    });
  }, [data, theme, height]);
  return <canvas ref={ref} width={360} height={height} style={{ width: '100%', height }} />;
}

function WindSpeedChart({ data, theme }) {
  const ref = useRef(null);
  const wrapRef = useRef(null);
  const draw = useCallback(() => {
    const c = ref.current, w = wrapRef.current;
    if (!c || !w) return;
    c.width = w.offsetWidth; c.height = w.offsetHeight;
    const ctx = c.getContext('2d');
    const W = c.width, H = c.height;
    if (!H || !W) return;
    ctx.clearRect(0, 0, W, H);
    const max = Math.max(...data.map(d => d.v)) * 1.15, bw = W / data.length;
    data.forEach((d, i) => {
      ctx.globalAlpha = i >= data.length - 3 ? 1 : 0.25 + (i / data.length) * 0.45;
      ctx.fillStyle = theme.chartPos;
      const bh = (d.v / max) * H;
      ctx.fillRect(i * bw + 1, H - bh, bw - 2, bh);
    });
    ctx.globalAlpha = 1;
    const lastH = (data[data.length - 1].v / max) * H;
    ctx.strokeStyle = theme.primary; ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(W - (W / data.length) * 3, H - lastH);
    ctx.lineTo(W, H - lastH);
    ctx.stroke();
  }, [data, theme]);
  useEffect(() => { draw(); }, [draw]);
  return (
    <div ref={wrapRef} style={{ flex: 1, width: '100%' }}>
      <canvas ref={ref} style={{ display: 'block', width: '100%', height: '100%' }} />
    </div>
  );
}

function LineChart({ data, theme, height = 120, yPad = 5 }) {
  const W = 360, H = height;
  const pd = { t: 10, r: 44, b: 16, l: 10 };
  const iW = W - pd.l - pd.r, iH = H - pd.t - pd.b;
  const minV = Math.min(...data) - yPad;
  const maxV = Math.max(...data) + yPad;
  const range = maxV - minV || 1;
  const pts = data.map((v, i) => ({
    x: pd.l + (i / (data.length - 1)) * iW,
    y: pd.t + (1 - (v - minV) / range) * iH,
  }));
  const d = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
  const lp = pts[pts.length - 1];
  return (
    <svg width="100%" height={height} viewBox={`0 0 ${W} ${H}`} style={{ display: 'block' }}>
      {[0.25, 0.5, 0.75].map((f, i) => (
        <line key={i} x1={pd.l} y1={pd.t + iH * f} x2={W - pd.r} y2={pd.t + iH * f}
          stroke={theme.border} strokeWidth={0.5} strokeDasharray="2 4" />
      ))}
      <path d={d} fill="none" stroke={theme.primary} strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" />
      {pts.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={i === pts.length - 1 ? 4 : 2}
          fill={i === pts.length - 1 ? theme.primary : theme.card}
          stroke={theme.primary} strokeWidth={1.5} />
      ))}
      <text x={W - pd.r + 4} y={lp.y + 4} fill={theme.primary}
        fontFamily="Barlow Condensed" fontSize={10} fontWeight={700}>{data[data.length - 1]}°</text>
    </svg>
  );
}

function ForecastSparkline({ data, theme, height = 52 }) {
  const W = 360, H = height, pd = 8;
  const iW = W - pd * 2, iH = H - pd * 2;
  const minV = Math.min(...data) - 3, maxV = Math.max(...data) + 3;
  const range = maxV - minV || 1;
  const pts = data.map((v, i) => ({
    x: pd + (i / (data.length - 1)) * iW,
    y: pd + (1 - (v - minV) / range) * iH,
  }));
  const d = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
  return (
    <svg width="100%" height={height} viewBox={`0 0 ${W} ${H}`} style={{ display: 'block' }}>
      <path d={d} fill="none" stroke={theme.primary} strokeWidth={1.5}
        strokeLinejoin="round" strokeLinecap="round" opacity={0.7} />
    </svg>
  );
}

function ShiftRelChart({ data, theme, height = 110 }) {
  const ref = useRef(null);
  useEffect(() => {
    const c = ref.current; if (!c) return;
    const ctx = c.getContext('2d');
    const W = c.width, H = c.height;
    ctx.clearRect(0, 0, W, H);
    const bw = W / data.length, mid = H * 0.5, max = 12;
    const lvls = [
      { y: 0.05, l: 'SB +10°' }, { y: 0.25, l: 'SB +5°' },
      { y: 0.5,  l: 'MARK'   },
      { y: 0.75, l: 'PT −5°' }, { y: 0.95, l: 'PT −10°' },
    ];
    ctx.font = '600 8px Barlow Condensed'; ctx.textAlign = 'right';
    lvls.forEach(({ y, l }) => {
      const yy = H * y;
      ctx.strokeStyle = l === 'MARK' ? theme.textDim + '80' : theme.border;
      ctx.lineWidth = l === 'MARK' ? 1 : 0.5; ctx.setLineDash([2, 4]);
      ctx.beginPath(); ctx.moveTo(0, yy); ctx.lineTo(W - 42, yy); ctx.stroke();
      ctx.setLineDash([]); ctx.fillStyle = theme.textDim;
      ctx.fillText(l, W - 2, yy + 3);
    });
    data.forEach((d, i) => {
      const norm = d / max;
      ctx.globalAlpha = 0.3 + (i / data.length) * 0.7;
      ctx.fillStyle = d >= 0 ? theme.chartPos : theme.chartNeg;
      if (d >= 0) ctx.fillRect(i * bw + 0.5, mid - norm * H * 0.44, bw - 1, norm * H * 0.44);
      else ctx.fillRect(i * bw + 0.5, mid, bw - 1, Math.abs(norm) * H * 0.44);
    });
    ctx.globalAlpha = 1;
  }, [data, theme, height]);
  return <canvas ref={ref} width={360} height={height} style={{ width: '100%', height }} />;
}

Object.assign(window, { WindShiftChart, WindSpeedChart, LineChart, ForecastSparkline, ShiftRelChart });
