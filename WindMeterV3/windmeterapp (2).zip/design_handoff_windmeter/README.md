# Handoff: WindMeter v3 — Sailing Instrument App

## Overview
WindMeter is a mobile sailing instrument app for racing sailors. It provides real-time wind data, race area analysis, course bias, countdown timer, roll angle, and GPS track recording — all optimised for fast glances on the water. The design targets an iOS phone form factor.

## About the Design Files
The files in this bundle are **design references created as HTML prototypes** — they show the intended look, layout, and interactive behaviour of the app. They are **not production code to copy directly**.

The task is to **recreate these designs in your target codebase** using its established framework (React Native, SwiftUI, Flutter, etc.) and component libraries. The HTML/JSX prototype is a high-fidelity reference for layout, colours, typography, spacing, and interactions.

## Fidelity
**High-fidelity.** The prototype uses final colours, typography, spacing, and interactions. Recreate the UI pixel-precisely using the measurements below.

---

## Design Tokens

### Colors
```
Background          #07090f   (C.bg)
Card surface        #0c1018   (C.card)
Card alt / headers  #0a0e16   (C.cardAlt)
Separator / border  #18263a   (C.sep)
Cyan accent         #00ddc0   (C.cyan)
Cyan dim bg         rgba(0,221,192,0.18)   (C.cyanDim)
Cyan glow bg        rgba(0,221,192,0.08)   (C.cyanGlow)
Primary text        #ffffff   (C.text)
Secondary text      rgba(255,255,255,0.55) (C.textSub)
Dim label text      #2a4255   (C.textDim)
Warning / negative  #f5a623   (C.neg)
```

### Typography
- **Primary font:** Barlow Condensed (weights 300, 400, 600, 700, 800; also italic 800)
- **Body font:** Barlow (weights 400, 500, 600)
- Google Fonts import: `Barlow Condensed` + `Barlow`

#### Type scale in use
| Role | Family | Size | Weight | Letter-spacing |
|---|---|---|---|---|
| Hero number | Barlow Condensed | 175px | 800 | −0.02em |
| Large number | Barlow Condensed | 72–80px | 800 | −0.01em |
| Medium number | Barlow Condensed | 34–48px | 800 | −0.01em |
| Timer display | Barlow Condensed | 170px | 800 | 0.01em |
| Section header | Barlow Condensed | 15px | 800 | 0.2em |
| Section label (SL) | Barlow Condensed | 11px | 700 | 0.16em |
| Mini label | — | 9px | 700 | 0.16em |
| Body copy | Barlow | 12px | 400 | — |
| Caption | Barlow Condensed | 8–9px | 700 | 0.06–0.1em |

### Shadow
```
Hero numbers: 0 0 40px rgba(0,0,0,0.9), 0 2px 0 rgba(0,0,0,0.6)
```

### Spacing
- Screen horizontal padding: **14px**
- Section label padding: `5px 14px 3px`
- Standard card padding: `8–10px 14px`
- Button border-radius: **6px** (standard), **8px** (large)
- Separator border: `1px solid #18263a`

---

## App Shell

### Device Container
- Overall height: **874px** (iPhone-sized)
- Top padding (status bar): **62px**
- Bottom padding (home indicator): **34px**
- Background: `#07090f`
- Layout: flex column, `overflow: hidden`

### Header Bar
- Background: `#0c1018`
- Border bottom: `1px solid #18263a`
- Padding: `5px 14px`
- Title: Barlow Condensed, 15px, weight 800, `#00ddc0`, letter-spacing 0.2em — shows current tab name (ALL CAPS)
- Right slot: settings gear icon button (taps into Settings overlay)

### Tab Bar
- 6 tabs: **PRE · AREA · COURSE · START · RACE · TRACK**
- Height: ~34px, fixed to bottom
- Background: `#0c1018`, top border `1px solid #18263a`
- Active tab: `#00ddc0`, weight 800
- Inactive tab: `#2a4255`, weight 700
- Font: Barlow Condensed, 9px, letter-spacing 0.14em
- Tapping a tab swaps the screen content (no animation required)

---

## Shared Components

### SL — Section Label Row
A full-width header row used above every data section.
```
Background:    #0a0e16
Border-bottom: 1px solid #18263a
Padding:       5px 14px 3px
Left text:     11px, weight 700, #2a4255, letter-spacing 0.16em
Right text:    11px, weight 700, #00ddc0 (optional)
```

### HeroCard
Large number display with a SL label above and optional sub-label.
```
Background:     #07090f
Border-bottom:  1px solid #18263a
flexShrink:     0

Number:   Barlow Condensed, 175px, weight 800, #ffffff, lineHeight 0.88,
          letter-spacing −0.02em, text-shadow: NUM_SHADOW, centered
Unit:     Barlow Condensed, 30px, weight 700, #00ddc0, positioned bottom-right (14px from edges)
Sub:      Barlow Condensed, 24px, weight 700, #00ddc0, margin-top 2px
Inner padding: 4px 14px 8px
minHeight: 100px
```

### MiniRow
Horizontal row of 2–3 equal-width stat cells, separated by vertical dividers.
```
Background:     #0c1018
Border-bottom:  1px solid #18263a
Cell padding:   7px 12px 8px
Label:          9px, weight 700, #2a4255, letter-spacing 0.16em, margin-bottom 2px
Value:          Barlow Condensed, 34px, weight 800, #ffffff, lineHeight 1
Unit suffix:    Barlow Condensed, 13px, weight 700, #00ddc0
```

### ChartSection
Wrapper for a canvas chart with a label and optional time-axis labels.
```
Background:     #07090f
Border-bottom:  1px solid #18263a
flexShrink:     0

Header:         SL component
Chart area:     padding-top 4px, contains BarChart canvas
Time labels:    flex row, space-between, padding 1px 14px 5px
                8px, #2a4255, letter-spacing 0.06em
```

### BarChart (canvas)
Canvas-based bar chart. Two modes:
- **Standard** (midline=false): bars grow upward from bottom, single colour
- **Shift** (midline=true): bars grow up (positive/cyan) or down (negative/amber) from centreline

```
Default height: 90–100px
Bar colors:
  Positive: #00ddc0
  Negative: #f5a623
Alpha fade: 0.2 at oldest → 1.0 at newest (left to right)
Midline label: '+10°' / '−10°', 8px Barlow Condensed, #2a4255
Canvas fills container width (100%)
```

### AdjBtn — Adjustment Button
```
Height:         44px
flex: 1 (equal width in a row)
Background:     none
Border:         1px solid #18263a, border-radius 6px
Text:           Barlow Condensed, 25px, weight 700, #ffffff
```

### Pill Button
```
Border:         1px solid (active: #00ddc0, inactive: #18263a)
Border-radius:  4px
Padding:        2px 8px
Text:           Barlow Condensed, 11px, weight 700
Color:          active #00ddc0 / inactive #2a4255
```

### Segmented Control (Settings)
```
flex row, gap 5px, flex-wrap
Each option:    flex 1, padding 10px 4px
Active:         bg rgba(0,221,192,0.18), border #00ddc0, color #00ddc0
Inactive:       bg none, border #18263a, color #2a4255
Border-radius:  6px, font Barlow Condensed 11px weight 700
```

---

## Screens

### PRE — Pre-Start
**Purpose:** Live wind data + 12h forecast.

**Layout (top → bottom):**
1. Search bar row (input + SEARCH button), padding 8px 12px, bg `#0c1018`
2. Location subtitle row, padding 4px 16px, bg `#0a0e16`
3. Three-column MiniRow: DIRECTION (89°, compass), WIND KTS (4.5), GUST KTS (12.1) — values at 50px
4. ChartSection: "WIND DIRECTION — NEXT 12H" with BarChart (height 50, fill mode), time axis NOW→00:00
5. Scrollable forecast list — one row per hour:
   - Time (Barlow Condensed 11px), Bearing (28px weight 800), Compass dir (11px #00ddc0), Speed (20px), "G" gust indicator (#2a4255)
   - Row padding 8px 16px, first row (NOW) has `rgba(0,221,192,0.05)` bg

**State:** Location search (no real API in prototype), live wind updates every 2.5s.

---

### AREA — Race Area
**Purpose:** Log TWD readings to track wind history during the pre-race period. Ping start line ends.

**Layout:**
1. HeroCard: "TWD" — current area TWD in degrees
2. LOG READING button (large, full-width, cyan outline) + LAST LOGGED counter side panel
   - Button: height ~60px, bg `rgba(0,221,192,0.18)`, border `1px solid #00ddc0`, font 30px
   - Panel: bg `#0c1018`, border `1px solid #18263a`, border-radius 8px; value 28px, label 9px
3. START LINE section header
4. Two rows: COMMITTEE + PIN END — each has PING / RESET buttons
   - PING active state: cyan outline/bg; RESET active state: amber outline
5. Height spacer (8px, bg `#07090f`)
6. TWD HISTORY flex-fill chart (SVG bars, ±shift from first log, fills remaining height)
   - Cyan bars = port shift (lower °), amber bars = stbd shift (higher °)
   - Reference lines at ±5° and ±10°

---

### COURSE — Course Analysis
**Purpose:** Set the mark bearing, see current wind shift relative to mark, and get a LEFT/RIGHT/NEUTRAL tack-advantage recommendation.

**Layout (scrollable):**
1. HeroCard: "MARK BEARING" — large degree display, sub = compass direction
   - Four AdjBtn row below: −10, −1, +1, +10
2. MiniRow (3 cols): TWD | SHIFT | LIFTED
   - SHIFT value coloured: positive = cyan, negative = amber
   - LIFTED cell: a 14px-tall bar indicator, half left (port/amber) half right (stbd/cyan), centred divider
3. ChartSection: "SHIFT RELATIVE TO MARK  · += STARBOARD LIFTED"
   - BarChart, height 100, midline=true, 31 data points
   - Time labels: −30m, −15m, NOW
4. Favour section (padding 16px 14px):
   - Mini label "FAVOUR" + shift value in cyan
   - Large word: LEFT / NEUTRAL / RIGHT (64px Barlow Condensed, weight 800)
     - LEFT = `#f5a623`, RIGHT = `#00ddc0`, NEUTRAL = `rgba(255,255,255,0.55)`
   - Sub-label: "PORT LIFTED" / "STBD LIFTED" / "EVEN" (22px)
   - Descriptive text (Barlow 12px, `rgba(255,255,255,0.55)`)

**State:** `markBearing` (int, 0–359). `shift = TWD − markBearing`. Favour threshold: |shift| > 3°.

---

### START — Start Sequence
**Purpose:** Countdown timer with start/pause/reset/sync + distance to line placeholder + line bias placeholder.

**Layout:**
1. **Countdown section** (flexShrink 0):
   - SL "COUNTDOWN" with duration label right
   - Full-width progress bar (3px, cyan → amber as time runs out, `≤33%` remaining)
   - Timer display: **170px** Barlow Condensed weight 800, lineHeight 0.88
     - Colour: white normally, amber at ≤120s, `#f5a623` at ≤60s
     - Colon separator: opacity 0.4
   - Button row: START/PAUSE · RESET · SYNC (flex equal, 12px padding, border-radius 6px)
     - Active (START): bg `#00ddc0`, text `#07090f`
     - Inactive: no fill, border `#18263a`, text white
2. **Distance to Start Line** section:
   - 4px progress bar (35% filled as placeholder)
   - Caption "Ping both ends in AREA tab to measure"
3. **Line Bias** section (flex 1): compass SVG placeholder

**State:** `time` counts down from `timerDur × 60`. SYNC snaps to nearest whole minute.

---

### RACE — Racing
**Purpose:** Show COG (course over ground) from GPS and roll angle from device motion.

**Layout:**
1. **COG section** (flexShrink 0):
   - SL "COG — COURSE OVER GROUND"
   - Half-circle compass arc (SVG, 120×70, stroke `#18263a`) with compass labels
   - Large "—°" placeholder (72px, colour `#2a4255`, awaiting GPS)
   - GPS permission note (red dot + caption)
2. **ROLL section** (flex 1):
   - Header row with "ROLL" label + ACTIVATE toggle pill
   - Circular compass rose SVG (160×160)
   - When inactive: "Motion permission required" caption
   - When active: live roll degrees (48px, cyan)

---

### TRACK — Track Session
**Purpose:** GPS track recording with elapsed timer.

**Layout:**
1. **Recording control** (flexShrink 0):
   - SL: "TRACK SESSION" / "RECORDING" (changes on state)
   - START RECORDING / STOP RECORDING button (flex 1) — cyan when inactive, amber when recording
   - Elapsed timer (36px) at right — dim when standby, cyan when recording
2. **Map area** (flex 1):
   - Subtle cyan grid overlay (SVG pattern, opacity 0.12)
   - Status text centred: "NO ACTIVE RECORDING / START TO BEGIN TRACK" or recording message

---

### SETTINGS (overlay)
Replaces screen content when gear icon tapped. Full-screen scrollable list:

| Setting | Type | Options |
|---|---|---|
| TIMER DURATION | Segmented | 3 MIN / 5 MIN / 10 MIN |
| BEEP VOLUME | Segmented | QUIET / MEDIUM / LOUD / MAX |
| ROLL REFRESH | Segmented | FAST / MEDIUM / SLOW |
| API KEY | Password input + SAVE button | sk-ant-… |
| ABOUT | Static text | App version + attribution |

---

## Interactions & Behaviour

| Interaction | Behaviour |
|---|---|
| Tab tap | Instantly swaps screen, no transition |
| Mark bearing ± buttons | Increments/decrements by stated amount, wraps at 0/360 |
| LOG READING (AREA) | Appends current TWD to readings array |
| PING / RESET (AREA) | Toggles committeeSet / pinSet boolean |
| START/PAUSE timer | Toggles interval; RESET restores full duration |
| SYNC timer | Rounds time to nearest whole minute |
| START/STOP TRACK | Toggles recording boolean; STOP resets elapsed duration |
| Live wind update | Every 2500ms — random walk on TWD and TWS |
| Settings gear | Toggles `showSettings` boolean overlay |

---

## State Architecture

```
App (root)
├── tab: 'PRE' | 'AREA' | 'COURSE' | 'START' | 'RACE' | 'TRACK'
├── showSettings: boolean
├── live: { twd, tws, sd[], spd[] }       — live wind (updates every 2.5s)
├── area: { twd, readings[], committeeSet, pinSet }
├── course: { markBearing }
└── settings: { timerDur, beep, roll, apiKey }
```

---

## Assets
No external images or icons. All visual elements are:
- SVG inline (compass arcs, grid patterns, bearing indicators)
- Canvas 2D (bar charts)
- CSS/text-based UI

---

## Files in This Package

| File | Description |
|---|---|
| `WindMeter v3.html` | Main hi-fi prototype — open in any browser |
| `ios-frame.jsx` | iOS device bezel component (status bar, home indicator) |
| `README.md` | This document |

---

## Notes for Implementation

1. **All text is ALL-CAPS** throughout the UI — apply `text-transform: uppercase` globally or per component.
2. **Canvas charts** should be replaced with your charting library of choice (Victory, Recharts, d3, MPAndroidChart, Swift Charts, etc.) — the visual style (dark bg, opacity fade on bars, midline) should be preserved.
3. **Live wind data** in the prototype is a seeded random walk — wire to real sensor/API data in production.
4. **GPS and motion APIs** are not implemented in the prototype (placeholders shown) — implement using CoreLocation / CLLocationManager (iOS) or equivalent.
5. **localStorage persistence** is not implemented in this prototype — add persistence for tab state, settings, and course/area data.
6. The **timer** should use a high-precision interval in production (or `Date`-diffing) to avoid drift.
