// wm-screens.jsx — All screen components for WindMeter
const { useState, useEffect, useMemo } = React;

function compassDir(d) {
  const dirs = ['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW'];
  return dirs[Math.round(((d % 360) + 360) % 360 / 22.5) % 16];
}

const Lbl = ({ children, theme }) => (
  <div style={{ fontFamily:'Barlow Condensed', fontSize:10, fontWeight:700, letterSpacing:'0.14em', color:theme.textDim }}>{children}</div>
);

const SegBtn = ({ label, active, onClick, theme }) => (
  <button onClick={onClick} style={{
    flex:1, padding:'8px 2px', background: active ? theme.primary+'22' : 'transparent',
    border:`1px solid ${active ? theme.primary : theme.border}`, borderRadius:6,
    color: active ? theme.primary : theme.textDim, fontFamily:'Barlow Condensed',
    fontSize:11, fontWeight:700, letterSpacing:'0.08em', cursor:'pointer', transition:'all .12s',
  }}>{label}</button>
);

// ── PRE Screen ─────────────────────────────────────────────────────────────
const FORECAST = [
  { t:'NOW',   d:60, c:'ENE', w:6.4, g:10.9 },
  { t:'10:00', d:68, c:'ENE', w:5.1, g:10.5 },
  { t:'11:00', d:70, c:'ENE', w:5.1, g:10.5 },
  { t:'12:00', d:68, c:'ENE', w:6.8, g:13.8 },
  { t:'13:00', d:68, c:'ENE', w:7.4, g:15.4 },
  { t:'14:00', d:68, c:'ENE', w:6.8, g:15.4 },
  { t:'15:00', d:65, c:'ENE', w:8.0, g:16.5 },
  { t:'16:00', d:61, c:'ENE', w:7.8, g:16.5 },
  { t:'17:00', d:50, c:'NE',  w:7.6, g:15.9 },
  { t:'18:00', d:47, c:'NE',  w:8.9, g:17.5 },
];

function PreScreen({ state, theme }) {
  const [query, setQuery] = useState('aalsmeer');
  const spark = FORECAST.map(f => f.d);
  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ display:'flex', gap:8, padding:'8px 12px', background:theme.card, borderBottom:`1px solid ${theme.border}`, flexShrink:0 }}>
        <input value={query} onChange={e => setQuery(e.target.value)}
          style={{ flex:1, background:theme.bg, border:`1px solid ${theme.border}`, borderRadius:8, padding:'8px 12px', color:theme.text, fontFamily:'Barlow Condensed', fontSize:13, outline:'none', letterSpacing:'0.04em' }} />
        <button style={{ background:theme.primary+'22', border:`1px solid ${theme.primary}`, borderRadius:8, color:theme.primary, fontFamily:'Barlow Condensed', fontSize:11, fontWeight:800, letterSpacing:'0.12em', padding:'0 14px', cursor:'pointer' }}>SEARCH</button>
      </div>
      <div style={{ padding:'4px 16px', background:theme.cardAlt, borderBottom:`1px solid ${theme.border}`, flexShrink:0 }}>
        <span style={{ fontFamily:'Barlow Condensed', fontSize:11, color:theme.textDim, letterSpacing:'0.05em' }}>{state.location}</span>
      </div>
      <div style={{ display:'flex', borderBottom:`1px solid ${theme.border}`, flexShrink:0 }}>
        {[
          { l:'DIRECTION', v:`${state.dir}°`, s:compassDir(state.dir) },
          { l:'WIND KTS',  v:state.wind.toFixed(1), s:'KTS' },
          { l:'GUST KTS',  v:state.gust.toFixed(1), s:'KTS' },
        ].map(({ l, v, s }, i) => (
          <div key={i} style={{ flex:1, padding:'8px 6px 8px', background:theme.card, borderRight:i<2?`1px solid ${theme.border}`:'none', display:'flex', flexDirection:'column', gap:2, overflow:'hidden' }}>
            <Lbl theme={theme}>{l}</Lbl>
            <div style={{ fontFamily:'Barlow Condensed', fontSize:50, fontWeight:800, color:theme.text, lineHeight:1, letterSpacing:'-0.02em', marginTop:2 }}>{v}</div>
            <div style={{ fontFamily:'Barlow Condensed', fontSize:13, fontWeight:700, color:theme.primary, letterSpacing:'0.06em', marginTop:2 }}>{s}</div>
          </div>
        ))}
      </div>
      <div style={{ padding:'4px 0 0', background:theme.cardAlt, borderBottom:`1px solid ${theme.border}`, flexShrink:0 }}>
        <div style={{ padding:'0 12px' }}><Lbl theme={theme}>WIND DIRECTION — NEXT 12H</Lbl></div>
        <ForecastSparkline data={spark} theme={theme} height={50} />
        <div style={{ display:'flex', justifyContent:'space-between', padding:'0 12px 4px' }}>
          {['07:00','11:00','15:00','19:00'].map(l => <span key={l} style={{ fontFamily:'Barlow Condensed', fontSize:9, color:theme.textDim }}>{l}</span>)}
        </div>
      </div>
      <div style={{ flex:1, overflowY:'auto' }}>
        {FORECAST.map((f, i) => (
          <div key={i} style={{ display:'flex', alignItems:'center', padding:'8px 16px', borderBottom:`1px solid ${theme.border}`, background:i===0?theme.primary+'0d':'transparent' }}>
            <span style={{ fontFamily:'Barlow Condensed', fontSize:12, fontWeight:i===0?700:500, color:i===0?theme.primary:theme.textDim, width:44 }}>{f.t}</span>
            <span style={{ fontFamily:'Barlow Condensed', fontSize:14, fontWeight:700, color:theme.text, width:38 }}>{f.d}°</span>
            <span style={{ fontFamily:'Barlow Condensed', fontSize:12, color:theme.primary, width:36 }}>{f.c}</span>
            <span style={{ fontFamily:'Barlow Condensed', fontSize:14, fontWeight:700, color:theme.text, flex:1 }}>{f.w.toFixed(1)} kts</span>
            <span style={{ fontFamily:'Barlow Condensed', fontSize:12, color:theme.textDim }}>G {f.g.toFixed(1)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── AREA Screen ────────────────────────────────────────────────────────────
function AreaScreen({ state, onUpdate, theme }) {
  const adj = d => onUpdate({ twd: Math.round(((state.twd + d) % 360 + 360) % 360) });
  const log = () => onUpdate({ readings: [...state.readings, state.twd] });
  const history = useMemo(() => {
    const base = state.readings[0] || 176;
    const pre = Array.from({ length: 20 }, (_, i) => Math.round(base + Math.sin(i * 0.4 + 1) * 6));
    return [...pre, ...state.readings];
  }, [state.readings]);

  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ background:theme.card, borderBottom:`1px solid ${theme.border}`, padding:'10px 16px 8px', flexShrink:0 }}>
        <div style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
          <Lbl theme={theme}>WIND DIRECTION (TWD)</Lbl>
          <span style={{ fontFamily:'Barlow Condensed', fontSize:10, fontWeight:700, color:theme.primary }}>MANUAL</span>
        </div>
        <div style={{ display:'flex', alignItems:'center' }}>
          <div style={{ display:'flex', gap:6, flex:1 }}>
            {[[-10,'−10'],[-1,'−1']].map(([d,l]) => (
              <button key={l} onClick={() => adj(d)} style={{ flex:1, height:40, background:'none', border:`1px solid ${theme.border}`, borderRadius:8, color:theme.text, fontFamily:'Barlow Condensed', fontSize:13, fontWeight:700, cursor:'pointer' }}>{l}</button>
            ))}
          </div>
          <div style={{ flex:2, textAlign:'center', padding:'0 8px' }}>
            <div style={{ fontFamily:'Barlow Condensed', fontSize:100, fontWeight:800, color:theme.text, lineHeight:0.9, letterSpacing:'-0.02em' }}>{state.twd}°</div>
            <div style={{ fontFamily:'Barlow Condensed', fontSize:20, fontWeight:700, color:theme.primary, letterSpacing:'0.08em', marginTop:4 }}>{compassDir(state.twd)}</div>
          </div>
          <div style={{ display:'flex', gap:6, flex:1 }}>
            {[[1,'+1'],[10,'+10']].map(([d,l]) => (
              <button key={l} onClick={() => adj(d)} style={{ flex:1, height:40, background:'none', border:`1px solid ${theme.border}`, borderRadius:8, color:theme.text, fontFamily:'Barlow Condensed', fontSize:13, fontWeight:700, cursor:'pointer' }}>{l}</button>
            ))}
          </div>
        </div>
      </div>
      <div style={{ display:'flex', borderBottom:`1px solid ${theme.border}`, flexShrink:0 }}>
        <button onClick={log} style={{ flex:1, padding:'13px', background:'none', border:'none', borderRight:`1px solid ${theme.border}`, color:theme.text, fontFamily:'Barlow Condensed', fontSize:14, fontWeight:700, letterSpacing:'0.12em', cursor:'pointer' }}
          onPointerDown={e => e.currentTarget.style.background=theme.primary+'1a'}
          onPointerUp={e => e.currentTarget.style.background='none'}>
          LOG READING
        </button>
        <div style={{ padding:'8px 14px', textAlign:'right', minWidth:110, background:theme.cardAlt }}>
          <div style={{ fontFamily:'Barlow Condensed', fontSize:9, color:theme.textDim, letterSpacing:'0.1em' }}>LAST LOGGED</div>
          <div style={{ fontFamily:'Barlow Condensed', fontSize:22, fontWeight:800, color:theme.primary }}>{state.readings[state.readings.length-1] ?? '—'}°</div>
          <div style={{ fontFamily:'Barlow Condensed', fontSize:9, color:theme.textDim }}>{state.readings.length} readings</div>
        </div>
      </div>
      {[['COMMITTEE', 0], ['PIN END', 1]].map(([nm, idx]) => {
        const pinged = idx === 0 ? state.committeeSet : state.pinSet;
        const upd = v => onUpdate(idx === 0 ? { committeeSet:v } : { pinSet:v });
        return (
          <div key={nm} style={{ display:'flex', alignItems:'center', borderBottom:`1px solid ${theme.border}`, background:theme.cardAlt, flexShrink:0 }}>
            <span style={{ fontFamily:'Barlow Condensed', fontSize:11, fontWeight:700, color:theme.textDim, letterSpacing:'0.1em', padding:'0 16px', flex:1 }}>{nm}</span>
            <button onClick={() => upd(true)} style={{ flex:2, padding:'12px', background:pinged?theme.primary+'1a':'none', border:'none', borderLeft:`1px solid ${theme.border}`, borderRight:`1px solid ${theme.border}`, color:pinged?theme.primary:theme.textDim, fontFamily:'Barlow Condensed', fontSize:11, fontWeight:700, letterSpacing:'0.1em', cursor:'pointer' }}>
              {pinged ? '✓ PINGED' : 'PING'}
            </button>
            <button onClick={() => upd(false)} style={{ flex:1, padding:'12px', background:'none', border:'none', color:theme.textDim, fontFamily:'Barlow Condensed', fontSize:11, fontWeight:700, letterSpacing:'0.1em', cursor:'pointer' }}>RESET</button>
          </div>
        );
      })}
      <div style={{ padding:'5px 16px', flexShrink:0 }}>
        <span style={{ fontFamily:'Barlow Condensed', fontSize:9, color:theme.textDim+'66', letterSpacing:'0.08em' }}>GPS: awaiting location</span>
      </div>
      <div style={{ flex:1, background:theme.cardAlt, borderTop:`1px solid ${theme.border}`, padding:'6px 12px 6px', display:'flex', flexDirection:'column' }}>
        <Lbl theme={theme}>TWD HISTORY (LAST 35 MIN)</Lbl>
        <LineChart data={history} theme={theme} height={140} />
        <div style={{ display:'flex', justifyContent:'space-between' }}>
          <span style={{ fontFamily:'Barlow Condensed', fontSize:9, color:theme.textDim }}>−35m</span>
          <span style={{ fontFamily:'Barlow Condensed', fontSize:9, color:theme.textDim }}>NOW</span>
        </div>
      </div>
    </div>
  );
}

// ── COURSE Screen ──────────────────────────────────────────────────────────
function CourseScreen({ areaState, state, onUpdate, theme }) {
  const twd = areaState.twd;
  const mark = state.markBearing;
  const shift = parseFloat((twd - mark).toFixed(1));
  const shiftStr = (shift >= 0 ? '+' : '') + shift + '°';
  const favour = shift > 3 ? 'RIGHT' : shift < -3 ? 'LEFT' : 'NEUTRAL';
  const favourColor = { LEFT:'#ff6b6b', RIGHT:'#4ade80', NEUTRAL:theme.textDim }[favour];
  const liftedPct = Math.max(-1, Math.min(1, shift / 12));
  const shiftHistory = useMemo(() => (
    Array.from({ length: 30 }, (_, i) => parseFloat((shift * 0.5 + Math.sin(i * 0.35) * 4 + (i > 15 ? (i-15) * (shift < 0 ? -0.4 : 0.4) : 0)).toFixed(1)))
  ), [shift]);

  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ background:theme.card, borderBottom:`1px solid ${theme.border}`, padding:'8px 16px 10px', flexShrink:0 }}>
        <Lbl theme={theme}>MARK BEARING</Lbl>
        <div style={{ display:'flex', alignItems:'center', gap:8, marginTop:4 }}>
          <button onClick={() => onUpdate({ markBearing: ((mark-1+360)%360) })} style={{ width:44, height:44, background:'none', border:`1px solid ${theme.border}`, borderRadius:8, color:theme.text, fontFamily:'Barlow Condensed', fontSize:22, fontWeight:700, cursor:'pointer' }}>−</button>
          <div style={{ flex:1, textAlign:'center', fontFamily:'Barlow Condensed', fontSize:92, fontWeight:800, color:theme.text, lineHeight:0.9, letterSpacing:'-0.02em' }}>{mark}°</div>
          <button onClick={() => onUpdate({ markBearing: ((mark+1)%360) })} style={{ width:44, height:44, background:'none', border:`1px solid ${theme.border}`, borderRadius:8, color:theme.text, fontFamily:'Barlow Condensed', fontSize:22, fontWeight:700, cursor:'pointer' }}>+</button>
        </div>
      </div>
      <div style={{ display:'flex', borderBottom:`1px solid ${theme.border}`, flexShrink:0 }}>
        <div style={{ flex:1, padding:'10px 12px', borderRight:`1px solid ${theme.border}` }}>
          <Lbl theme={theme}>TWD</Lbl>
          <div style={{ fontFamily:'Barlow Condensed', fontSize:48, fontWeight:800, color:theme.text, lineHeight:1.1 }}>{twd}°</div>
        </div>
        <div style={{ flex:1, padding:'10px 12px', borderRight:`1px solid ${theme.border}` }}>
          <Lbl theme={theme}>SHIFT</Lbl>
          <div style={{ fontFamily:'Barlow Condensed', fontSize:48, fontWeight:800, lineHeight:1.1, color:shift>0?theme.chartPos:shift<0?theme.chartNeg:theme.text }}>{shiftStr}</div>
        </div>
        <div style={{ flex:1, padding:'10px 12px' }}>
          <Lbl theme={theme}>LIFTED</Lbl>
          <div style={{ marginTop:8, height:14, background:theme.border, borderRadius:4, overflow:'hidden', position:'relative' }}>
            <div style={{ position:'absolute', top:0, bottom:0, left:liftedPct<0?`${50+liftedPct*50}%`:'50%', width:`${Math.abs(liftedPct)*50}%`, background:liftedPct>0?'#4ade80':'#ff6b6b', borderRadius:3 }}/>
            <div style={{ position:'absolute', top:0, bottom:0, left:'50%', width:1, background:theme.textDim }}/>
          </div>
        </div>
      </div>
      <div style={{ padding:'6px 12px 4px', background:theme.cardAlt, borderBottom:`1px solid ${theme.border}`, flexShrink:0 }}>
        <Lbl theme={theme}>SHIFT RELATIVE TO MARK  (+= SB LIFTED)</Lbl>
        <ShiftRelChart data={shiftHistory} theme={theme} height={110} />
        <div style={{ display:'flex', justifyContent:'space-between' }}>
          {['−30m','−15m','NOW'].map(l => <span key={l} style={{ fontFamily:'Barlow Condensed', fontSize:9, color:theme.textDim }}>{l}</span>)}
        </div>
      </div>
      <div style={{ flex:1, background:theme.card, padding:'12px 16px', display:'flex', flexDirection:'column', justifyContent:'center' }}>
        <div style={{ display:'flex', alignItems:'baseline', gap:10, marginBottom:8 }}>
          <Lbl theme={theme}>FAVOUR</Lbl>
          <div style={{ fontFamily:'Barlow Condensed', fontSize:64, fontWeight:800, color:favourColor, lineHeight:1 }}>{favour}</div>
        </div>
        <div style={{ fontFamily:'Barlow Condensed', fontSize:12, color:theme.primary, letterSpacing:'0.04em', marginBottom:4 }}>
          Wind trending {favour==='LEFT'?'left':favour==='RIGHT'?'right':'steady'} ({shiftStr})
        </div>
        <div style={{ fontFamily:'Barlow', fontSize:12, color:theme.textDim, lineHeight:1.6 }}>
          {favour==='LEFT'?'Port tack lifted. Favour left side of course.':favour==='RIGHT'?'Starboard tack lifted. Favour right side of course.':'Wind aligned with mark. No clear tack advantage.'}
        </div>
      </div>
    </div>
  );
}

// ── START Screen ───────────────────────────────────────────────────────────
function StartScreen({ settings, theme }) {
  const total = settings.timerDuration * 60;
  const [time, setTime] = useState(total);
  const [running, setRunning] = useState(false);
  useEffect(() => {
    if (!running) return;
    const iv = setInterval(() => setTime(t => Math.max(0, t - 1)), 1000);
    return () => clearInterval(iv);
  }, [running]);
  useEffect(() => { setTime(settings.timerDuration * 60); setRunning(false); }, [settings.timerDuration]);
  const mm = String(Math.floor(time / 60)).padStart(2, '0');
  const ss = String(time % 60).padStart(2, '0');
  const pct = time / total;
  const timerColor = time <= 60 ? theme.chartNeg : time <= 120 ? theme.secondary : theme.text;

  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ background:theme.card, borderBottom:`1px solid ${theme.border}`, padding:'12px 16px 14px', flexShrink:0 }}>
        <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10 }}>
          <Lbl theme={theme}>COUNTDOWN</Lbl>
          <div style={{ flex:1, height:3, background:theme.border, borderRadius:2, overflow:'hidden' }}>
            <div style={{ width:`${pct*100}%`, height:'100%', background:pct>0.33?theme.primary:theme.chartNeg, transition:'width 1s linear, background 0.5s' }}/>
          </div>
          <span style={{ fontFamily:'Barlow Condensed', fontSize:10, color:theme.textDim }}>{settings.timerDuration}:00</span>
        </div>
        <div style={{ textAlign:'center', padding:'4px 0' }}>
          <div style={{ fontFamily:'Barlow Condensed', fontSize:100, fontWeight:800, lineHeight:1, letterSpacing:'0.02em', color:timerColor, transition:'color .5s' }}>
            {mm}<span style={{ opacity:.5, marginInline:2 }}>:</span>{ss}
          </div>
        </div>
        <div style={{ display:'flex', gap:8, marginTop:12 }}>
          {[
            { l:running?'PAUSE':'START', p:!running, fn:()=>setRunning(r=>!r) },
            { l:'RESET', p:false, fn:()=>{ setRunning(false); setTime(total); } },
            { l:'SYNC',  p:false, fn:()=>setTime(Math.round(time/60)*60) },
          ].map(b => (
            <button key={b.l} onClick={b.fn} style={{ flex:1, padding:'12px', borderRadius:8, cursor:'pointer', background:b.p?theme.primary:'none', border:`1px solid ${b.p?theme.primary:theme.border}`, color:b.p?theme.bg:theme.text, fontFamily:'Barlow Condensed', fontSize:12, fontWeight:700, letterSpacing:'0.12em', transition:'all .15s' }}>{b.l}</button>
          ))}
        </div>
      </div>
      <div style={{ background:theme.cardAlt, borderBottom:`1px solid ${theme.border}`, padding:'10px 16px', flexShrink:0 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
          <Lbl theme={theme}>DISTANCE TO START LINE</Lbl>
          <button style={{ background:'none', border:`1px solid ${theme.border}`, borderRadius:6, padding:'4px 10px', color:theme.textDim, fontFamily:'Barlow Condensed', fontSize:9, fontWeight:700, letterSpacing:'0.1em', cursor:'pointer' }}>WATCH ●</button>
        </div>
        <div style={{ height:6, background:theme.border, borderRadius:3, marginBottom:6, overflow:'hidden' }}>
          <div style={{ width:'35%', height:'100%', background:theme.primary, borderRadius:3 }}/>
        </div>
        <div style={{ fontFamily:'Barlow Condensed', fontSize:10, color:theme.textDim+'88', letterSpacing:'0.06em' }}>Ping both ends in Area tab to measure</div>
      </div>
      <div style={{ flex:1, background:theme.card, padding:'10px 16px', display:'flex', flexDirection:'column' }}>
        <Lbl theme={theme}>LINE BIAS</Lbl>
        <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:10 }}>
          <div style={{ width:56, height:56, borderRadius:'50%', border:`2px dashed ${theme.border}`, display:'flex', alignItems:'center', justifyContent:'center' }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={theme.textDim} strokeWidth="1.5" strokeLinecap="round">
              <circle cx="12" cy="12" r="10"/><path d="M12 8v4l2 2"/>
            </svg>
          </div>
          <div style={{ fontFamily:'Barlow Condensed', fontSize:10, color:theme.textDim, letterSpacing:'0.1em', textAlign:'center' }}>PING BOTH ENDS TO CALCULATE</div>
        </div>
      </div>
    </div>
  );
}

// ── RACE Screen ────────────────────────────────────────────────────────────
function RaceScreen({ theme }) {
  const [rollActive, setRollActive] = useState(false);
  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ background:theme.card, borderBottom:`1px solid ${theme.border}`, padding:'10px 16px 12px', flexShrink:0 }}>
        <Lbl theme={theme}>COG</Lbl>
        <div style={{ display:'flex', alignItems:'center', gap:16, marginTop:8 }}>
          <svg width={80} height={46} viewBox="0 0 80 46">
            <path d="M4 44 A36 36 0 0 1 76 44" fill="none" stroke={theme.border} strokeWidth={5} strokeLinecap="round"/>
            <path d="M4 44 A36 36 0 0 1 40 8" fill="none" stroke={theme.primary} strokeWidth={5} strokeLinecap="round" opacity={0.5}/>
            <circle cx={40} cy={44} r={4} fill={theme.primary}/>
          </svg>
          <div>
            <div style={{ fontFamily:'Barlow Condensed', fontSize:10, color:theme.textDim, letterSpacing:'0.1em' }}>REQUIRES GPS</div>
            <div style={{ fontFamily:'Barlow Condensed', fontSize:72, fontWeight:800, color:theme.textDim, lineHeight:1 }}>—°</div>
          </div>
        </div>
      </div>
      <div style={{ padding:'7px 16px', borderBottom:`1px solid ${theme.border}`, background:theme.cardAlt, flexShrink:0 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <div style={{ width:6, height:6, borderRadius:'50%', background:theme.chartNeg, flexShrink:0 }}/>
          <span style={{ fontFamily:'Barlow Condensed', fontSize:10, color:theme.textDim, letterSpacing:'0.04em' }}>GPS permission not granted — enable in iOS Settings</span>
        </div>
      </div>
      <div style={{ flex:1, background:theme.card, padding:'10px 16px', display:'flex', flexDirection:'column' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
          <Lbl theme={theme}>ROLL</Lbl>
          <button onClick={() => setRollActive(r => !r)} style={{ background:rollActive?theme.primary+'22':'none', border:`1px solid ${rollActive?theme.primary:theme.border}`, borderRadius:6, padding:'4px 12px', cursor:'pointer', color:rollActive?theme.primary:theme.textDim, fontFamily:'Barlow Condensed', fontSize:9, fontWeight:700, letterSpacing:'0.1em' }}>{rollActive?'● ACTIVE':'TAP TO ACTIVATE'}</button>
        </div>
        <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:12 }}>
          <div style={{ width:150, height:150, borderRadius:'50%', border:`2px solid ${theme.border}`, display:'flex', alignItems:'center', justifyContent:'center', position:'relative' }}>
            <div style={{ width:100, height:100, borderRadius:'50%', border:`2px solid ${theme.border+'88'}`, display:'flex', alignItems:'center', justifyContent:'center' }}>
              <span style={{ fontFamily:'Barlow Condensed', fontSize:36, fontWeight:700, color:rollActive?theme.primary:theme.textDim }}>{rollActive?'—':'·'}</span>
            </div>
          </div>
          {!rollActive && <div style={{ fontFamily:'Barlow Condensed', fontSize:11, color:theme.textDim, letterSpacing:'0.08em', textAlign:'center' }}>Motion permission required</div>}
        </div>
      </div>
    </div>
  );
}

// ── TRACK Screen ───────────────────────────────────────────────────────────
function TrackScreen({ state, onUpdate, theme }) {
  const [dur, setDur] = useState(0);
  useEffect(() => {
    if (!state.recording) { setDur(0); return; }
    const iv = setInterval(() => setDur(d => d + 1), 1000);
    return () => clearInterval(iv);
  }, [state.recording]);
  const mm = String(Math.floor(dur / 60)).padStart(2, '0');
  const ss = String(dur % 60).padStart(2, '0');
  return (
    <div style={{ flex:1, display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <div style={{ background:theme.card, borderBottom:`1px solid ${theme.border}`, padding:'10px 12px', display:'flex', gap:10, alignItems:'center', flexShrink:0 }}>
        <button onClick={() => onUpdate({ recording:!state.recording })} style={{ flex:1, padding:'13px', borderRadius:8, cursor:'pointer', background:state.recording?theme.chartNeg+'22':theme.primary+'22', border:`1px solid ${state.recording?theme.chartNeg:theme.primary}`, color:state.recording?theme.chartNeg:theme.primary, fontFamily:'Barlow Condensed', fontSize:12, fontWeight:800, letterSpacing:'0.14em', display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
          <div style={{ width:8, height:8, borderRadius:state.recording?2:'50%', background:state.recording?theme.chartNeg:theme.primary, transition:'border-radius 0.2s' }}/>
          {state.recording?'STOP RECORDING':'START RECORDING'}
        </button>
        <div style={{ textAlign:'right', minWidth:82 }}>
          <div style={{ fontFamily:'Barlow Condensed', fontSize:22, fontWeight:800, color:state.recording?theme.primary:theme.textDim }}>{mm}:{ss}</div>
          <div style={{ fontFamily:'Barlow Condensed', fontSize:9, color:theme.textDim, letterSpacing:'0.08em' }}>{state.recording?'RECORDING':'no recording'}</div>
        </div>
      </div>
      <div style={{ flex:1, background:theme.bg, position:'relative', overflow:'hidden', display:'flex', alignItems:'center', justifyContent:'center' }}>
        <svg width="100%" height="100%" style={{ position:'absolute', inset:0, opacity:0.2 }} preserveAspectRatio="none">
          <defs><pattern id="tgrid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke={theme.border} strokeWidth={0.5}/></pattern></defs>
          <rect width="100%" height="100%" fill="url(#tgrid)"/>
        </svg>
        <div style={{ textAlign:'center', position:'relative', zIndex:1, padding:'0 24px' }}>
          <div style={{ fontFamily:'Barlow Condensed', fontSize:10, color:theme.textDim, letterSpacing:'0.14em', lineHeight:2.2 }}>
            RECORDING STARTS AUTOMATICALLY AT GUN<br/>OR TAP START TO RECORD MANUALLY
          </div>
        </div>
      </div>
    </div>
  );
}

// ── SETTINGS Screen ────────────────────────────────────────────────────────
function SettingsScreen({ settings, onUpdate, theme }) {
  const S = ({ title, note, children }) => (
    <div style={{ padding:'12px 16px', borderBottom:`1px solid ${theme.border}` }}>
      <div style={{ fontFamily:'Barlow Condensed', fontSize:10, fontWeight:700, letterSpacing:'0.16em', color:theme.primary, marginBottom:10 }}>{title}</div>
      {children}
      {note && <div style={{ fontFamily:'Barlow', fontSize:11, color:theme.textDim, marginTop:8, lineHeight:1.5 }}>{note}</div>}
    </div>
  );
  return (
    <div style={{ flex:1, overflowY:'auto' }}>
      <S title="START TIMER DURATION" note="Takes effect on next RESET. Default is 5 minutes.">
        <div style={{ display:'flex', gap:6 }}>
          {[3,5,10].map(v => <SegBtn key={v} label={`${v} MIN`} active={settings.timerDuration===v} onClick={() => onUpdate({timerDuration:v})} theme={theme}/>)}
        </div>
      </S>
      <S title="BEEP VOLUME" note="Controls timer signal volume.">
        <div style={{ display:'flex', gap:6 }}>
          {['QUIET','MEDIUM','LOUD','MAX'].map(v => <SegBtn key={v} label={v} active={settings.beepVolume===v.toLowerCase()} onClick={() => onUpdate({beepVolume:v.toLowerCase()})} theme={theme}/>)}
        </div>
      </S>
      <S title="ROLL REFRESH RATE" note="Slower = smoother but less responsive.">
        <div style={{ display:'flex', gap:5, flexWrap:'wrap' }}>
          {['FAST','MEDIUM','SLOW','VERY SLOW'].map(v => <SegBtn key={v} label={v} active={settings.rollRate===v.toLowerCase().replace(' ','-')} onClick={() => onUpdate({rollRate:v.toLowerCase().replace(' ','-')})} theme={theme}/>)}
        </div>
      </S>
      <S title="ANTHROPIC API KEY" note="Stored locally on this device only.">
        <input value={settings.apiKey} onChange={e => onUpdate({apiKey:e.target.value})} placeholder="sk-ant-…" type="password"
          style={{ width:'100%', background:theme.bg, border:`1px solid ${theme.border}`, borderRadius:8, padding:'10px 12px', color:theme.text, fontFamily:'Barlow Condensed', fontSize:13, outline:'none', marginBottom:8, boxSizing:'border-box' }}/>
        <button style={{ width:'100%', padding:'12px', background:theme.primary+'22', border:`1px solid ${theme.primary}`, borderRadius:8, color:theme.primary, fontFamily:'Barlow Condensed', fontSize:13, fontWeight:800, letterSpacing:'0.12em', cursor:'pointer' }}>SAVE KEY</button>
      </S>
      <div style={{ padding:'14px 16px 24px' }}>
        <Lbl theme={theme}>ABOUT</Lbl>
        <div style={{ fontFamily:'Barlow Condensed', fontSize:15, fontWeight:600, color:theme.text, marginTop:6 }}>WindMeter v2.1</div>
        <div style={{ fontFamily:'Barlow', fontSize:12, color:theme.textDim, marginTop:3 }}>Manual TWD · Claude AI</div>
      </div>
    </div>
  );
}

Object.assign(window, { compassDir, Lbl, SegBtn, PreScreen, AreaScreen, CourseScreen, StartScreen, RaceScreen, TrackScreen, SettingsScreen });
